from rest_framework import serializers


class UserRegistration(serializers.Serializer):
    email_id = serializers.IntegerField()
    email_name = serializers.CharField()
    pass_word = serializers.CharField()


class FavoriteMovies(serializers.Serializer):
    movie_id = serializers.IntegerField()
    movie_title = serializers.CharField()
    release_date = serializers.DateField()
    synopsis = serializers.CharField()
    vote_average = serializers.FloatField()
    vote_count = serializers.IntegerField()
    email_id = serializers.IntegerField()