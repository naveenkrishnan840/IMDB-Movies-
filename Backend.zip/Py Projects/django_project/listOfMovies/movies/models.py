from django.db import models

# Create your models here.


class UserRegistration(models.Model):
    email_id = models.AutoField(primary_key=True)
    email_name = models.CharField(max_length=100)
    pass_word = models.CharField(max_length=1000)


class FavoriteMovies(models.Model):
    movie_id = models.AutoField(primary_key=True)
    movie_title = models.CharField(max_length=100)
    release_date = models.DateField()
    synopsis = models.CharField(max_length=1000)
    vote_average = models.FloatField(null=True)
    vote_count = models.IntegerField(null=True)
    email = models.ForeignKey(to=UserRegistration, on_delete=models.CASCADE)
