import json
from hashlib import md5
from django.shortcuts import render, HttpResponse
from . import models
from django import views
from rest_framework.views import APIView
from rest_framework.response import Response
from . import serializer
# Create your views here.




class ImdbMovies(APIView):
    def get(self, request):
        return HttpResponse('sdf')

    def post(self, request):
        if request.data[0] == "RegisterUser":
            email = request.data[1]["email"]
            password = md5(request.data[1]["password"].encode()).hexdigest()
            if not models.UserRegistration.objects.filter(email_name=email).exists():
                models.UserRegistration.objects.create(email_name=email, pass_word=password)
                response = ["UserRegistrationSuccess", {}]

            else:
                response = ["Already Have Account", {}]
        elif request.data[0] == "LoginUser":
            email = request.data[1]["email"]
            password = md5(request.data[1]["password"].encode()).hexdigest()
            user_data = models.UserRegistration.objects.filter(email_name=email, pass_word=password)
            if user_data.exists():
                last_user = user_data.last()
                user_details = serializer.UserRegistration(last_user).data
                response = ["UserLogInSuccess", user_details]

            else:
                response = ["UserLogInFailed", {}]
        elif request.data[0] == "SaveSelectedMoviesForUser":
            email_id = request.data[1][0]["user_id"]
            email = models.UserRegistration.objects.filter(email_id=email_id)
            movies_det = request.data[1][0]["movies_list"]
            for movie in movies_det:
                title = movie["title"]
                release_date = movie["release_date"]
                synopsis = movie["synopsis"]
                vote_average = movie["vote_average"]
                vote_count = movie["vote_count"]
                if not models.FavoriteMovies.objects.filter(movie_title=title).exists():
                    models.FavoriteMovies.objects.create(movie_title=title, release_date=release_date, synopsis=synopsis,
                                                         vote_average=vote_average, vote_count=vote_count, email=email[0])

                else:
                    response = ["UserSelectedMoviesFailed", {'movie_title': title}]
                    break
            else:
                response = ["UserSelectedMoviesSuccess", {}]
        elif request.data[0] == "GetSelectedMoviesForUser":
            email_id = request.data[1]["user"]
            movies_details = models.FavoriteMovies.objects.filter(email_id=email_id)
            serializer_data = [serializer.FavoriteMovies(query_set).data for query_set in movies_details]
            response = ["GetSelectedMoviesForUserSuccess", serializer_data]
        elif request.data[0] == "getUserDeletedMovie":
            movie_id = request.data[1]["movie_id"]
            models.FavoriteMovies.objects.filter(movie_id=movie_id).delete()
            response = ["getUserDeletedMovieSuccess", {}]
        response = json.dumps(response)
        return Response(response)
