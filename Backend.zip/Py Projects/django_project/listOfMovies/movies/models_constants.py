from django.apps import apps
from .models import *

# userRegistration = apps.get_model("user_registration", UserRegistration)
# favoriteMovies = apps.get_model("favorite_movies", FavoriteMovies)
