from . import views
from django.urls import path

urlpatterns = [
    path("movies", views.ImdbMovies.as_view(), name="ImdbMovies")
]