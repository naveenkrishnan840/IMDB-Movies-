import axios from "axios";
import {message} from "antd";
axios.defaults.baseURL = "http://localhost:8000/";
export const register = ({payload, navigate}) => async dispatch=>  {
    try {
        console.log(axios);
        const data = ["RegisterUser", payload];
        const str_body = JSON.stringify(data)
        // const body = encode(str_body)
        const request = await axios({
            method: "POST",
            url: "movies",
            headers: { Accept:'application/json',
                            'Content-Type': 'application/json',
                    //    'X-CSRF-TOKEN': document.getElementsByName('csrf-token')[0].content
                    },
            data:str_body
        });
        // const request = await axios({'/movies?' + body})
        console.log(request)
        if (request["status"] == 200){
            const response = JSON.parse(request["data"])
            if (response[0] == "UserRegistrationSuccess"){
                message.success("Successfully Created Account")
                navigate.push("/signin");
            } else {
                message.info("Already have Account Please Log in")
            }
                
        } else {
            message.error("Submission Failed")
        }
        
    } catch (error) {
        
    }
}

export const SignIn = ({payload, navigate}) => async dispatch=>  {
    try {
        const data = ["LoginUser", payload];
        const str_body = JSON.stringify(data)
        const request = await axios({
            method: "POST",
            url: "movies",
            headers: {  'Accept':'application/json',
                        'Content-Type': 'application/json'
                    },
            data:str_body
        });
        console.log(request)
        if (request["status"] == 200){
            const response = JSON.parse(request["data"])
            if (response[0] == "UserLogInSuccess"){
                message.success("Successfully Account Login")
                dispatch({
                    type: response[0],
                    payload: response[1]
                })
                navigate.push("/list_of_movies")
            } else {
                message.error("Invalid Login")
            }
                
        } else {
            message.error("Submission Failed")
        }
        
    } catch (error) {
        
    }
}

export const SelectedMovies = ({user, payload}) => async dispatch=>  {
    try {
        const data1 = [{user_id:user, movies_list: payload}]
        const data = ["SaveSelectedMoviesForUser", data1];
        const str_body = JSON.stringify(data)
        const request = await axios({
            method: "POST",
            url: "movies",
            headers: {  'Accept':'application/json',
                        'Content-Type': 'application/json'
                    },
            data:str_body
        });
        console.log(request)
        if (request["status"] == 200){
            const response = JSON.parse(request["data"])
            if (response[0] == "UserSelectedMoviesFailed"){
                message.warning(response[1]["movie_title"] + " movie is already Saved");
            } else {
                message.success("Selected Movies Saved Successfully")
            }
        } else {
            message.error("Something Went Wrong")
        }
        
    } catch (error) {
        
    }
}

export const getUserSelectedMovies = ({user}) => async dispatch=>  {
    try {
        const data = ["GetSelectedMoviesForUser", user];
        const str_body = JSON.stringify(data)
        const request = await axios({
            method: "POST",
            url: "movies",
            headers: {  'Accept':'application/json',
                        'Content-Type': 'application/json'
                    },
            data:str_body
        });
        console.log(request)
        if (request["status"] == 200){
            const response = JSON.parse(request["data"])
            if (response[0] == "GetSelectedMoviesForUserSuccess"){
                dispatch({type:"FovMovies", payload: response[1]})
            } 
        } else {
            message.error("Something Went Wrong")
        }
        
    } catch (error) {
        
    }
} 

export const getUserDeletedMovie = ({movie_id}) => async dispatch=>  {
    try {
        const data = ["getUserDeletedMovie", {movie_id: movie_id}];
        const str_body = JSON.stringify(data)
        const request = await axios({
            method: "POST",
            url: "movies",
            headers: {  'Accept':'application/json',
                        'Content-Type': 'application/json'
                    },
            data:str_body
        });
        console.log(request)
        if (request["status"] == 200){
            const response = JSON.parse(request["data"])
            if (response[0] == "getUserDeletedMovieSuccess"){
                message.success("Selected Movies Successfully Removed!")
            } 
        } else {
            message.error("Something Went Wrong")
        }
        
    } catch (error) {
        
    }
} 