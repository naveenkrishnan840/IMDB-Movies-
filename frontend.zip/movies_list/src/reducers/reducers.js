const initailState = {
        user_id: "",
        email_name: "",
        movies_list: [],
        fov_movies: []
}


export default function (state=initailState, action) {
    const {type, payload} = action;

    switch (type) {
        case "UserLogInSuccess":{
            return {
                ...state,
                user_id: payload["email_id"],
                email_name: payload["email_name"]
                }
            }
        case "ListOFMovies":
            return {
                ...state,
                movies_list: payload
            } 
        case "FovMovies":
            return {
                ...state,
                fov_movies: payload
            }        
        default:
            return state
    }
}    