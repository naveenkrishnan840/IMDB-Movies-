import React, {useEffect, useState} from 'react';
import { connect, useDispatch } from 'react-redux';
import axios from 'axios';
import {SelectedMovies} from "../actions/actions";
import { Table, Input, Button, Col, Row, message} from 'antd';


export const ListOfAllMovies = ({list_of_movies, SelectedMovies, user_id}) => {
  const [list_movies, setListMovies] = useState([]);
  const [sreach_movie, setSearchMovies] = useState("");
  const dispatch = useDispatch();
  const [selected_movies, setSelectedMovies] = useState([]);
 

  useEffect(()=>{
      if (sreach_movie){
        const filter_movie = list_of_movies.filter((a=>a.original_title.toLowerCase().includes(sreach_movie.toLowerCase())));
        setListMovies(filter_movie);
        // setSelectedMovies([]);
      } else {
        setListMovies(list_of_movies);
      }
  }, [sreach_movie])
  useEffect(() =>{
    if(list_of_movies.length == 0){
      async function api(){
        const response = await axios({
          method: "GET",
          url: "https://api.themoviedb.org/4/list/1?api_key=ae6a3e6e7d618b23a8f8ad9b9176c98d",
          headers: {  'Accept':'application/json',
                      'Content-Type': 'application/json'
                  }
      });
      console.log("response",response);
      dispatch({
        "type": "ListOFMovies",
        "payload": response.data["results"]
      })
      setListMovies(response.data["results"]);
      }
      api();
    } 
  },[])
  const columns = [
    {
      title: 'Original Title',
      // key: "Original Title",
      dataIndex: 'original_title'
    },
    {
      title: 'Release Date',
      // key: 'Release Date',
      dataIndex: 'release_date',
    },
    {
      title: 'Synposis',
      // key: 'Synposis',
      dataIndex: 'overview',
    },
    {
      title: 'Vote Average',
      // key: 'Vote Average',
      dataIndex: 'vote_average',
    },
    {
      title: 'Vote Count',
      // key: 'Vote Count',
      dataIndex: 'vote_count',
    },
  ];
  const rowSelection = {
    onChange: (selectedRowKeys, selectedRows) => {
      const rows = selectedRows.map((row)=>({title:row.original_title, release_date:row.release_date, synopsis:row.overview, 
                                              vote_average:row.vote_average, vote_count:row.vote_count}))
      setSelectedMovies(rows)
      // console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
    },
  }
  const onSelectedMovies = () =>{
    if (selected_movies.length > 0){
      SelectedMovies({user: user_id, payload: selected_movies});
    }else {
      message.warning("Please Select One Movie");
      // return;
    }
  }
  return (
    <>
      <Row gutter={16}>
        <Col span={7}>
          <Input placeholder='Search For Title ' style={{width:"100%"}} onChange={(e)=>{
            setSearchMovies(e.target.value)
          }}/>          
        </Col>
        <Button type='primary' onClick={onSelectedMovies}> Submit</Button>
       
      </Row>
        <Table          
          rowSelection={{
            type: "checkbox",
            ...rowSelection,
          }}  
          // rowKey={"id"}
          rowKey={obj =>obj.id}
          dataSource={list_movies} 
          columns={columns}>
        </Table>
    </>
  )
}
const mapStateToProps = (state) => ({
  list_of_movies: state.movies_list,
  user_id: state.user_id
})

const mapDispatchToProps = {SelectedMovies}

export default connect(mapStateToProps, mapDispatchToProps)(ListOfAllMovies)