import {
    MenuUnfoldOutlined,
    MenuFoldOutlined,
    UserOutlined,
    ArrowRightOutlined, LogoutOutlined
  } from '@ant-design/icons';
import {Route, Switch, Link} from "react-router-dom";  
import { Button, Layout, Menu, Space, theme } from 'antd';
import { useState } from 'react';
import ListOfAllMovies from "./list_of_all_movies";
import FavoriteMovies from "./favorite_movies";
import {connect} from "react-redux";
const { Header, Sider, Content } = Layout;

const mapStateToProps = (state) => ({
  email_name: state.email_name
});
const HeaderPage = ({email_name}) => {
  const [collapsed, setCollapsed] = useState(false);
  const {
    token: { colorBgContainer },
  } = theme.useToken();
  return (
    <Layout>
      <Sider trigger={null} collapsible collapsed={collapsed}>
        <div className="logo" />
        <Menu
          theme="dark"
          mode="inline"
          defaultSelectedKeys={['1']}
          items={[
            {
              key: '1',
              icon: <ArrowRightOutlined/>,
              label: <Link to="/list_of_movies">List Of Movies</Link>, 
            },
            {
              key: '2',
              icon: <UserOutlined />,
              label: <Link to="/favorite_movies">Favorite Movies</Link>,  
            },
            {
              key: '3',
              icon: <UserOutlined />,
              label: email_name,  
            },
            {
              key: '4',
              icon: <LogoutOutlined />,
              label: <Link to="/signin">Logout</Link>,  
            }
          ]}
        />
      </Sider>
      <Layout>
        <Header
          style={{
            padding: 0,
            background: colorBgContainer,
          }}
        >
          <Button
            type="text"
            icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
            onClick={() => setCollapsed(!collapsed)}
            style={{
              fontSize: '16px',
              width: 64,
              height: 64,
            }}
          />
          <Menu
          theme="dark"
          mode="inline"
          defaultSelectedKeys={['1']}
          items={[{
              key: '1',
              icon: '',
              label: "IMDB MOVIES"  
          }]}></Menu>
        </Header>
        <Content
          style={{
            margin: '24px 16px',
            padding: 24,
          //   minHeight: '700px',
            overflow: "initial",
            background: colorBgContainer,
          }}
        >
        <Switch>
          <Route exact path='/list_of_movies'><ListOfAllMovies/></Route>
          <Route exact path='/favorite_movies'><FavoriteMovies/></Route>
        </Switch>
        </Content>
      </Layout>
    </Layout>
  );
};
export default connect(mapStateToProps, {})(HeaderPage);
  